param(
    [string]$Configuration = "Release"
)

$ErrorActionPreference = "Stop"
$projectRoot = Split-Path -Parent $PSScriptRoot
$project = Join-Path $PSScriptRoot "WakeQR.csproj"
$publishDir = Join-Path $PSScriptRoot "bin\$Configuration\net8.0-windows\win-x64\publish"
$releaseDir = Join-Path $projectRoot "release"

Write-Host "[1/3] WakeQR Windows x64 단일 실행 파일 빌드"
dotnet restore $project
dotnet publish $project `
    -c $Configuration `
    -r win-x64 `
    --self-contained true `
    -p:PublishSingleFile=true `
    -p:PublishReadyToRun=true

New-Item -ItemType Directory -Force -Path $releaseDir | Out-Null
Copy-Item (Join-Path $publishDir "WakeQR.exe") (Join-Path $releaseDir "WakeQR.exe") -Force

Write-Host "[2/3] 설치 파일 생성 시도"
$compilerCandidates = @(
    "${env:ProgramFiles(x86)}\Inno Setup 6\ISCC.exe",
    "$env:ProgramFiles\Inno Setup 6\ISCC.exe"
)
$compiler = $compilerCandidates | Where-Object { Test-Path $_ } | Select-Object -First 1

if ($compiler) {
    & $compiler (Join-Path $PSScriptRoot "installer.iss")
    Copy-Item (Join-Path $PSScriptRoot "installer-output\WakeQR-Setup-1.0.0.exe") $releaseDir -Force
    Write-Host "[3/3] 완료: release\WakeQR.exe, release\WakeQR-Setup-1.0.0.exe"
} else {
    Write-Warning "Inno Setup 6을 찾지 못해 설치 파일은 건너뛰었습니다."
    Write-Host "[3/3] 완료: release\WakeQR.exe"
}
