#define MyAppName "WakeQR"
#define MyAppVersion "1.1.0"
#define MyAppPublisher "WakeMyPC"
#define MyAppExeName "WakeQR.exe"

[Setup]
AppId={{6A6C89F4-3B9D-4A41-9FC5-2710BAA3F9A1}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={autopf}\WakeQR
DefaultGroupName=WakeQR
PrivilegesRequired=admin
OutputDir=installer-output
OutputBaseFilename=WakeQR-Setup-{#MyAppVersion}
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible

[Files]
Source: "bin\Release\net8.0-windows\win-x64\publish\{#MyAppExeName}"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{group}\WakeQR"; Filename: "{app}\{#MyAppExeName}"
Name: "{autodesktop}\WakeQR"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon

[Tasks]
Name: "desktopicon"; Description: "바탕 화면 바로가기 만들기"; GroupDescription: "추가 바로가기:"

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "WakeQR 실행"; Flags: nowait postinstall skipifsilent
