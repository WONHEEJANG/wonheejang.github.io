import AppKit
import CoreImage
import Foundation
import SwiftUI

struct AdapterInfo {
    let interface: String
    let mac: String
    let ip: String
    let broadcast: String
    let gateway: String
}

enum ToolError: LocalizedError {
    case message(String)

    var errorDescription: String? {
        switch self {
        case .message(let value): value
        }
    }
}

enum NetworkInfo {
    static func current() throws -> AdapterInfo {
        let route = try command("/sbin/route", ["-n", "get", "default"])
        guard let interface = value(after: "interface:", in: route),
              let gateway = value(after: "gateway:", in: route) else {
            throw ToolError.message("현재 공유기와 네트워크 인터페이스를 찾지 못했습니다.")
        }

        let details = try command("/sbin/ifconfig", [interface])
        let lines = details.split(separator: "\n").map(String.init)
        guard let macLine = lines.first(where: { $0.trimmingCharacters(in: .whitespaces).hasPrefix("ether ") }),
              let inetLine = lines.first(where: { $0.trimmingCharacters(in: .whitespaces).hasPrefix("inet ") }) else {
            throw ToolError.message("활성 네트워크의 MAC 또는 IPv4 주소를 찾지 못했습니다.")
        }

        let macParts = macLine.split(whereSeparator: { $0 == " " || $0 == "\t" })
        let inetParts = inetLine.split(whereSeparator: { $0 == " " || $0 == "\t" })
        guard macParts.count >= 2,
              inetParts.count >= 2,
              let broadcastIndex = inetParts.firstIndex(of: "broadcast"),
              inetParts.indices.contains(broadcastIndex + 1) else {
            throw ToolError.message("활성 네트워크 정보를 해석하지 못했습니다.")
        }

        return AdapterInfo(
            interface: interface,
            mac: macParts[1].uppercased(),
            ip: String(inetParts[1]),
            broadcast: String(inetParts[broadcastIndex + 1]),
            gateway: gateway
        )
    }

    static func wakeForNetworkAccessEnabled() -> Bool {
        guard let output = try? command("/usr/bin/pmset", ["-g", "custom"]) else { return false }
        return output.range(of: #"\bwomp\s+1\b"#, options: .regularExpression) != nil
    }

    static func enableWakeForNetworkAccess() throws {
        let script = "do shell script \"/usr/bin/pmset -a womp 1\" with administrator privileges"
        _ = try command("/usr/bin/osascript", ["-e", script])
    }

    private static func command(_ executable: String, _ arguments: [String]) throws -> String {
        let process = Process()
        let pipe = Pipe()
        process.executableURL = URL(fileURLWithPath: executable)
        process.arguments = arguments
        process.standardOutput = pipe
        process.standardError = pipe
        try process.run()
        process.waitUntilExit()
        let data = pipe.fileHandleForReading.readDataToEndOfFile()
        let output = String(data: data, encoding: .utf8) ?? ""
        guard process.terminationStatus == 0 else {
            throw ToolError.message(output.trimmingCharacters(in: .whitespacesAndNewlines))
        }
        return output
    }

    private static func value(after key: String, in text: String) -> String? {
        text.split(separator: "\n")
            .map { $0.trimmingCharacters(in: .whitespaces) }
            .first(where: { $0.hasPrefix(key) })?
            .dropFirst(key.count)
            .trimmingCharacters(in: .whitespaces)
    }
}

private final class ServiceParser: NSObject, XMLParserDelegate {
    private var current = ""
    private var currentServiceType = ""
    private var currentControlURL = ""
    private(set) var serviceType: String?
    private(set) var controlURL: String?

    func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String: String] = [:]) {
        current = elementName.lowercased()
        if current == "service" {
            currentServiceType = ""
            currentControlURL = ""
        }
    }

    func parser(_ parser: XMLParser, foundCharacters string: String) {
        if current == "servicetype" { currentServiceType += string }
        if current == "controlurl" { currentControlURL += string }
    }

    func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?) {
        if elementName.lowercased() == "service",
           currentServiceType.contains("WANIPConnection") || currentServiceType.contains("WANPPPConnection") {
            serviceType = currentServiceType.trimmingCharacters(in: .whitespacesAndNewlines)
            controlURL = currentControlURL.trimmingCharacters(in: .whitespacesAndNewlines)
        }
        current = ""
    }
}

enum UPnPClient {
    static func configure(adapter: AdapterInfo, externalPort: Int, internalPort: Int) async throws -> String {
        let locations = try await Task.detached { try discoverLocations() }.value
        var lastError: Error = ToolError.message("UPnP 공유기를 찾지 못했습니다.")

        for location in locations {
            do {
                let (data, _) = try await URLSession.shared.data(from: location)
                let delegate = ServiceParser()
                let parser = XMLParser(data: data)
                parser.delegate = delegate
                guard parser.parse(),
                      let serviceType = delegate.serviceType,
                      let controlPath = delegate.controlURL,
                      let controlURL = URL(string: controlPath, relativeTo: location)?.absoluteURL else {
                    throw ToolError.message("공유기의 UPnP 제어 주소를 찾지 못했습니다.")
                }

                let externalIP = try await soap(
                    url: controlURL,
                    serviceType: serviceType,
                    action: "GetExternalIPAddress",
                    arguments: ""
                )
                guard let ip = tag("NewExternalIPAddress", in: externalIP), isPublicIPv4(ip) else {
                    throw ToolError.message("공유기가 공인 IPv4를 사용하지 않습니다. 통신사 이중 NAT 환경일 수 있습니다.")
                }

                let arguments = """
                <NewRemoteHost></NewRemoteHost>
                <NewExternalPort>\(externalPort)</NewExternalPort>
                <NewProtocol>UDP</NewProtocol>
                <NewInternalPort>\(internalPort)</NewInternalPort>
                <NewInternalClient>\(adapter.ip)</NewInternalClient>
                <NewEnabled>1</NewEnabled>
                <NewPortMappingDescription>WakeMyPC Mac</NewPortMappingDescription>
                <NewLeaseDuration>0</NewLeaseDuration>
                """
                _ = try await soap(
                    url: controlURL,
                    serviceType: serviceType,
                    action: "AddPortMapping",
                    arguments: arguments
                )
                return ip
            } catch {
                lastError = error
            }
        }
        throw lastError
    }

    private static func discoverLocations() throws -> [URL] {
        let fd = Darwin.socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)
        guard fd >= 0 else { throw ToolError.message("UPnP 검색 소켓을 열지 못했습니다.") }
        defer { Darwin.close(fd) }

        var timeout = timeval(tv_sec: 3, tv_usec: 0)
        setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &timeout, socklen_t(MemoryLayout.size(ofValue: timeout)))

        var destination = sockaddr_in()
        destination.sin_len = UInt8(MemoryLayout<sockaddr_in>.size)
        destination.sin_family = sa_family_t(AF_INET)
        destination.sin_port = in_port_t(1900).bigEndian
        inet_pton(AF_INET, "239.255.255.250", &destination.sin_addr)

        let message = "M-SEARCH * HTTP/1.1\r\nHOST: 239.255.255.250:1900\r\nMAN: \"ssdp:discover\"\r\nMX: 2\r\nST: upnp:rootdevice\r\n\r\n"
        let sent = message.withCString { pointer in
            withUnsafePointer(to: &destination) { address in
                address.withMemoryRebound(to: sockaddr.self, capacity: 1) {
                    Darwin.sendto(fd, pointer, strlen(pointer), 0, $0, socklen_t(MemoryLayout<sockaddr_in>.size))
                }
            }
        }
        guard sent >= 0 else { throw ToolError.message("공유기 검색 패킷을 보내지 못했습니다.") }

        var results: [URL] = []
        var buffer = [UInt8](repeating: 0, count: 8192)
        while true {
            let count = Darwin.recv(fd, &buffer, buffer.count - 1, 0)
            if count <= 0 { break }
            let response = String(decoding: buffer.prefix(count), as: UTF8.self)
            for line in response.split(separator: "\n") {
                let trimmed = line.trimmingCharacters(in: .whitespacesAndNewlines)
                if trimmed.lowercased().hasPrefix("location:"),
                   let url = URL(string: String(trimmed.dropFirst("location:".count)).trimmingCharacters(in: .whitespaces)),
                   !results.contains(url) {
                    results.append(url)
                }
            }
        }
        guard !results.isEmpty else { throw ToolError.message("UPnP 자동 설정을 지원하는 공유기를 찾지 못했습니다.") }
        return results
    }

    private static func soap(url: URL, serviceType: String, action: String, arguments: String) async throws -> String {
        let body = """
        <?xml version="1.0"?>
        <s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">
          <s:Body><u:\(action) xmlns:u="\(serviceType)">\(arguments)</u:\(action)></s:Body>
        </s:Envelope>
        """
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.httpBody = Data(body.utf8)
        request.setValue("\"\(serviceType)#\(action)\"", forHTTPHeaderField: "SOAPAction")
        request.setValue("text/xml; charset=utf-8", forHTTPHeaderField: "Content-Type")
        request.timeoutInterval = 8
        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
            throw ToolError.message("공유기가 \(action) 요청을 거부했습니다.")
        }
        return String(data: data, encoding: .utf8) ?? ""
    }

    private static func tag(_ name: String, in xml: String) -> String? {
        guard let start = xml.range(of: "<\(name)>", options: .caseInsensitive),
              let end = xml.range(of: "</\(name)>", options: .caseInsensitive, range: start.upperBound..<xml.endIndex) else { return nil }
        return String(xml[start.upperBound..<end.lowerBound]).trimmingCharacters(in: .whitespacesAndNewlines)
    }

    private static func isPublicIPv4(_ value: String) -> Bool {
        let parts = value.split(separator: ".").compactMap { Int($0) }
        guard parts.count == 4, parts.allSatisfy({ (0...255).contains($0) }) else { return false }
        if parts[0] == 10 || parts[0] == 127 || parts[0] >= 224 { return false }
        if parts[0] == 192 && parts[1] == 168 { return false }
        if parts[0] == 172 && (16...31).contains(parts[1]) { return false }
        if parts[0] == 100 && (64...127).contains(parts[1]) { return false }
        return true
    }
}

@MainActor
final class AppModel: ObservableObject {
    @Published var adapter: AdapterInfo?
    @Published var computerName = Host.current().localizedName ?? "내 Mac"
    @Published var externalAddress = ""
    @Published var externalPort = "40010"
    @Published var includeRemote = false
    @Published var wakeEnabled = false
    @Published var isWorking = false
    @Published var status = "네트워크 정보를 확인하고 있습니다."
    @Published var statusIsError = false
    @Published var qrImage: NSImage?

    init() { reload() }

    func reload() {
        do {
            adapter = try NetworkInfo.current()
            wakeEnabled = NetworkInfo.wakeForNetworkAccessEnabled()
            status = wakeEnabled
                ? "✓ 네트워크 연결 시 깨우기가 켜져 있습니다."
                : "네트워크 연결 시 깨우기를 먼저 켜 주세요."
            statusIsError = !wakeEnabled
            refreshQR()
        } catch {
            status = error.localizedDescription
            statusIsError = true
        }
    }

    func enableWake() {
        do {
            try NetworkInfo.enableWakeForNetworkAccess()
            reload()
        } catch {
            status = "설정을 적용하지 못했습니다: \(error.localizedDescription)"
            statusIsError = true
        }
    }

    func configureRouter() {
        guard let adapter, let port = Int(externalPort), (1...65535).contains(port) else { return }
        isWorking = true
        status = "공유기를 찾고 자동 포트 설정을 시도하고 있습니다…"
        statusIsError = false
        Task {
            do {
                let ip = try await UPnPClient.configure(adapter: adapter, externalPort: port, internalPort: 9)
                externalAddress = ip
                includeRemote = true
                status = "✓ 공유기 자동 설정 완료 · UDP \(port) → \(adapter.ip):9"
                refreshQR()
            } catch {
                includeRemote = false
                status = "자동 설정 불가 · QR 스캔 후 WakeMyPC의 공유기 안내를 따라 주세요."
                statusIsError = true
            }
            isWorking = false
        }
    }

    func refreshQR() {
        guard let adapter else { return }
        var components = URLComponents()
        components.scheme = "wakemypc"
        components.host = "add"
        var items = [
            URLQueryItem(name: "name", value: computerName),
            URLQueryItem(name: "mac", value: adapter.mac),
            URLQueryItem(name: "bc", value: adapter.broadcast),
            URLQueryItem(name: "port", value: "9"),
            URLQueryItem(name: "ip", value: adapter.ip),
            URLQueryItem(name: "gw", value: adapter.gateway),
            URLQueryItem(name: "device", value: "mac")
        ]
        if includeRemote, !externalAddress.trimmingCharacters(in: .whitespaces).isEmpty {
            items.append(URLQueryItem(name: "wan", value: externalAddress.trimmingCharacters(in: .whitespaces)))
            items.append(URLQueryItem(name: "wanPort", value: externalPort))
        }
        components.queryItems = items
        guard let data = components.url?.absoluteString.data(using: .utf8),
              let filter = CIFilter(name: "CIQRCodeGenerator") else { return }
        filter.setValue(data, forKey: "inputMessage")
        filter.setValue("M", forKey: "inputCorrectionLevel")
        guard let output = filter.outputImage?.transformed(by: CGAffineTransform(scaleX: 9, y: 9)),
              let cgImage = CIContext().createCGImage(output, from: output.extent) else { return }
        qrImage = NSImage(cgImage: cgImage, size: NSSize(width: 330, height: 330))
    }

    func openBatterySettings() {
        if let url = URL(string: "x-apple.systempreferences:com.apple.preference.battery") {
            NSWorkspace.shared.open(url)
        }
    }
}

struct ContentView: View {
    @StateObject private var model = AppModel()

    var body: some View {
        HStack(spacing: 0) {
            VStack(alignment: .leading, spacing: 17) {
                Text("WAKE ON LAN").font(.caption.bold()).tracking(2).foregroundStyle(.blue)
                Text("WakeQR for Mac").font(.system(size: 30, weight: .bold))
                Text("MacBook은 완전 종료가 아닌 잠자기 상태에서 깨울 수 있습니다.")
                    .font(.callout).foregroundStyle(.secondary)

                if let adapter = model.adapter {
                    GroupBox("현재 네트워크") {
                        VStack(alignment: .leading, spacing: 7) {
                            Text("\(adapter.interface)  ·  \(adapter.mac)")
                            Text("IPv4 \(adapter.ip)  ·  공유기 \(adapter.gateway)")
                        }.frame(maxWidth: .infinity, alignment: .leading)
                    }
                }

                HStack {
                    Button("네트워크 깨우기 켜기") { model.enableWake() }
                    Button("배터리 설정 열기") { model.openBatterySettings() }
                }

                Divider()
                TextField("Mac 이름", text: $model.computerName).onChange(of: model.computerName) { _ in model.refreshQR() }
                TextField("외부 주소 (공인 IP 또는 DDNS)", text: $model.externalAddress).onChange(of: model.externalAddress) { _ in model.refreshQR() }
                TextField("외부 UDP 포트", text: $model.externalPort).onChange(of: model.externalPort) { _ in model.refreshQR() }
                Toggle("외부 깨우기 정보를 QR에 포함", isOn: $model.includeRemote).onChange(of: model.includeRemote) { _ in model.refreshQR() }

                Button(model.isWorking ? "공유기 설정 중…" : "공유기 자동 설정 + 통합 QR") {
                    model.configureRouter()
                }
                .buttonStyle(.borderedProminent)
                .controlSize(.large)
                .disabled(model.isWorking || model.adapter == nil)

                Text(model.status)
                    .font(.footnote.weight(.semibold))
                    .foregroundStyle(model.statusIsError ? Color.orange : Color.green)
                    .fixedSize(horizontal: false, vertical: true)
                Spacer()
            }
            .padding(28)
            .frame(width: 480)

            VStack(spacing: 14) {
                Text("아이폰에서 QR 한 번 스캔").font(.title3.bold())
                if let image = model.qrImage {
                    Image(nsImage: image).interpolation(.none).resizable().frame(width: 330, height: 330)
                } else {
                    ProgressView().frame(width: 330, height: 330)
                }
                Text(model.includeRemote ? "Mac + 공유기 정보 포함" : "Mac 등록용 · 공유기는 앱에서 이어서 설정")
                    .font(.footnote).foregroundStyle(.secondary)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(Color(nsColor: .windowBackgroundColor).opacity(0.55))
        }
        .frame(width: 900, height: 610)
    }
}

@main
struct WakeQRMacApp: App {
    var body: some Scene {
        WindowGroup { ContentView() }
            .windowResizability(.contentSize)
    }
}
