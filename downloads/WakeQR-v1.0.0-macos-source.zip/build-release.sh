#!/bin/zsh
set -euo pipefail

SCRIPT_DIR=${0:A:h}
OUTPUT_DIR="$SCRIPT_DIR/release"
APP_DIR="$OUTPUT_DIR/WakeQR for Mac.app"

rm -rf "$OUTPUT_DIR"
mkdir -p "$APP_DIR/Contents/MacOS" "$APP_DIR/Contents/Resources"

xcrun swiftc \
  -O \
  -parse-as-library \
  -target arm64-apple-macos13.0 \
  "$SCRIPT_DIR/WakeQRMac.swift" \
  -o "$APP_DIR/Contents/MacOS/WakeQRMac" \
  -framework AppKit \
  -framework CoreImage \
  -framework SwiftUI

cp "$SCRIPT_DIR/Info.plist" "$APP_DIR/Contents/Info.plist"
codesign --force --deep --sign - "$APP_DIR"
ditto -c -k --sequesterRsrc --keepParent "$APP_DIR" "$OUTPUT_DIR/WakeQR-v1.0.0-macos-arm64.zip"

echo "완료: $OUTPUT_DIR/WakeQR-v1.0.0-macos-arm64.zip"
