# WakeMyPC

같은 로컬 네트워크의 Windows PC를 휴대폰에서 Wake-on-LAN으로 깨우는 앱입니다. Windows의 **WakeQR**가 PC 정보를 QR로 만들고, iOS/Android의 **WakeMyPC**가 이를 등록해 UDP 매직 패킷을 보냅니다.

## 구성

- `WakeQR/`: .NET 8 WinForms Windows 도구
- `WakeMyPC-RN/`: React Native iOS/Android 앱

QR과 딥링크는 다음 계약을 공유합니다.

```text
wakemypc://add?name={이름}&mac={MAC}&bc={브로드캐스트}&port={포트}
```

## 빠른 시작

### 1. Windows 도구

Windows 10/11 x64와 .NET 8 SDK가 필요합니다.

```powershell
dotnet restore .\WakeQR\WakeQR.csproj
dotnet run --project .\WakeQR\WakeQR.csproj
```

배포용 단일 실행 파일:

```powershell
dotnet publish .\WakeQR\WakeQR.csproj -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true
```

`WakeQR/installer.iss`를 Inno Setup으로 컴파일하면 설치 파일을 만들 수 있습니다.

### 2. 모바일 앱

Node.js 22.13 또는 24.3 이상의 지원 버전을 권장합니다. iOS는 Xcode와 CocoaPods, Android는 Android Studio/JDK가 필요합니다.

```bash
cd WakeMyPC-RN
npm install
npm run ios
# 또는
npm run android
```

iOS 의존성을 다시 설치해야 할 때:

```bash
cd WakeMyPC-RN/ios
pod install
open WakeMyPC.xcworkspace
```

## 구현된 v1 기능

- 연결된 실제 Ethernet/Wi-Fi 어댑터 탐색 및 가상 어댑터 제외
- IPv4 서브넷 브로드캐스트 자동 계산, QR 즉시 갱신
- 관리자 권한 PowerShell로 매직 패킷 깨우기 설정 및 빠른 시작 해제
- PC 수동 추가·편집·삭제와 기기 로컬 저장
- QR 스캔 및 `wakemypc://` 딥링크 등록, 동일 MAC 덮어쓰기
- 102바이트 매직 패킷을 UDP 브로드캐스트로 3회 전송
- iOS/Android 카메라·로컬 네트워크·딥링크 설정

## 실기기 확인 체크리스트

1. PC BIOS/UEFI에서 Wake on LAN 또는 PCIe Wake를 켭니다.
2. 가능하면 PC를 유선 LAN으로 연결합니다.
3. WakeQR의 **WOL 설정 자동 적용**을 실행합니다.
4. 휴대폰과 PC를 같은 서브넷에 연결하고 QR로 PC를 등록합니다.
5. PC를 종료한 뒤 랜 포트 LED가 유지되는지 확인하고 **깨우기**를 누릅니다.
6. 실패하면 공유기가 제한 브로드캐스트를 막는지, QR의 서브넷 브로드캐스트 주소가 맞는지 확인합니다.

외부망에서 직접 깨우는 기능은 v1 범위가 아닙니다. 필요하면 VPN/Tailscale을 별도로 구성해야 합니다.

## 검증 명령

```bash
cd WakeMyPC-RN
npx tsc --noEmit
npm run lint -- --max-warnings=0
npm test -- --runInBand
```
