using System.Diagnostics;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Text;
using QRCoder;

namespace WakeQR;

internal static class Program
{
    [STAThread]
    private static void Main()
    {
        Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
        Application.ThreadException += (_, args) => CrashReporter.Show(args.Exception);
        AppDomain.CurrentDomain.UnhandledException += (_, args) =>
            CrashReporter.Write(args.ExceptionObject as Exception ?? new Exception(args.ExceptionObject?.ToString()));

        try
        {
            ApplicationConfiguration.Initialize();
            Application.Run(new MainForm());
        }
        catch (Exception ex)
        {
            CrashReporter.Show(ex);
        }
    }
}

internal static class CrashReporter
{
    private static readonly string LogDirectory = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
        "WakeQR");

    public static void Write(Exception exception)
    {
        try
        {
            Directory.CreateDirectory(LogDirectory);
            File.AppendAllText(
                Path.Combine(LogDirectory, "WakeQR.log"),
                $"[{DateTimeOffset.Now:O}] WakeQR {Application.ProductVersion} | {Environment.OSVersion}\r\n{exception}\r\n\r\n");
        }
        catch
        {
            // Logging must never hide the original error.
        }
    }

    public static void Show(Exception exception)
    {
        Write(exception);
        MessageBox.Show(
            $"WakeQR를 실행하지 못했습니다.\n\n{exception.Message}\n\n오류 기록:\n{Path.Combine(LogDirectory, "WakeQR.log")}",
            "WakeQR 오류",
            MessageBoxButtons.OK,
            MessageBoxIcon.Error);
    }
}

internal sealed record AdapterInfo(
    string Name,
    string Description,
    string Mac,
    string Ip,
    string Broadcast,
    NetworkInterfaceType Type)
{
    public bool IsWifi => Type == NetworkInterfaceType.Wireless80211;
    public override string ToString() => $"{Name} ({Mac}){(IsWifi ? " · Wi-Fi" : string.Empty)}";
}

internal sealed class MainForm : Form
{
    private readonly ComboBox adapterBox = new() { DropDownStyle = ComboBoxStyle.DropDownList };
    private readonly TextBox nameBox = new();
    private readonly NumericUpDown portBox = new() { Minimum = 1, Maximum = 65535, Value = 9 };
    private readonly PictureBox qrBox = new() { SizeMode = PictureBoxSizeMode.Zoom };
    private readonly Label networkLabel = new();
    private readonly Label warningLabel = new();
    private readonly Label emptyLabel = new();
    private readonly Button applyButton = new();
    private readonly Label linkLabel = new();

    public MainForm()
    {
        Text = "WakeQR";
        ClientSize = new Size(760, 560);
        MinimumSize = new Size(720, 540);
        StartPosition = FormStartPosition.CenterScreen;
        BackColor = Color.FromArgb(245, 247, 251);
        Font = new Font("Segoe UI", 10F);

        BuildLayout();
        nameBox.Text = Environment.MachineName;
        nameBox.TextChanged += (_, _) => RefreshQr();
        portBox.ValueChanged += (_, _) => RefreshQr();
        adapterBox.SelectedIndexChanged += (_, _) => RefreshQr();
        LoadAdapters();
    }

    private void BuildLayout()
    {
        var root = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            Padding = new Padding(32),
            ColumnCount = 2,
            RowCount = 1,
            BackColor = BackColor,
        };
        root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 51));
        root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 49));
        Controls.Add(root);

        var left = new TableLayoutPanel { Dock = DockStyle.Fill, Padding = new Padding(0, 4, 26, 0), RowCount = 9 };
        left.RowStyles.Add(new RowStyle(SizeType.Absolute, 36));
        left.RowStyles.Add(new RowStyle(SizeType.Absolute, 48));
        left.RowStyles.Add(new RowStyle(SizeType.Absolute, 33));
        left.RowStyles.Add(new RowStyle(SizeType.Absolute, 70));
        left.RowStyles.Add(new RowStyle(SizeType.Absolute, 70));
        left.RowStyles.Add(new RowStyle(SizeType.Absolute, 54));
        left.RowStyles.Add(new RowStyle(SizeType.Absolute, 42));
        left.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        left.RowStyles.Add(new RowStyle(SizeType.Absolute, 56));
        root.Controls.Add(left, 0, 0);

        left.Controls.Add(new Label
        {
            Text = "WAKE ON LAN",
            ForeColor = Color.FromArgb(37, 99, 235),
            Font = new Font("Segoe UI", 9F, FontStyle.Bold),
            Dock = DockStyle.Fill,
            TextAlign = ContentAlignment.BottomLeft,
        });
        left.Controls.Add(new Label
        {
            Text = "WakeQR",
            ForeColor = Color.FromArgb(20, 33, 61),
            Font = new Font("Segoe UI", 24F, FontStyle.Bold),
            Dock = DockStyle.Fill,
        });
        left.Controls.Add(new Label
        {
            Text = "이 PC의 정보를 휴대폰으로 안전하게 옮깁니다.",
            ForeColor = Color.FromArgb(102, 112, 133),
            Dock = DockStyle.Fill,
        });

        left.Controls.Add(FieldPanel("네트워크 어댑터", adapterBox));
        left.Controls.Add(FieldPanel("PC 이름", nameBox));
        left.Controls.Add(FieldPanel("UDP 포트", portBox));

        networkLabel.Dock = DockStyle.Fill;
        networkLabel.ForeColor = Color.FromArgb(71, 84, 103);
        networkLabel.Font = new Font("Segoe UI", 9F);
        networkLabel.Padding = new Padding(2, 8, 0, 0);
        left.Controls.Add(networkLabel);

        warningLabel.Dock = DockStyle.Fill;
        warningLabel.ForeColor = Color.FromArgb(146, 64, 14);
        warningLabel.Padding = new Padding(10);
        warningLabel.BackColor = Color.FromArgb(255, 247, 237);
        warningLabel.Visible = false;
        left.Controls.Add(warningLabel);

        applyButton.Text = "WOL 설정 자동 적용";
        applyButton.Dock = DockStyle.Fill;
        applyButton.FlatStyle = FlatStyle.Flat;
        applyButton.FlatAppearance.BorderSize = 0;
        applyButton.BackColor = Color.FromArgb(20, 33, 61);
        applyButton.ForeColor = Color.White;
        applyButton.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
        applyButton.Cursor = Cursors.Hand;
        applyButton.Click += async (_, _) => await ApplyWolSettingsAsync();
        left.Controls.Add(applyButton);

        var right = new Panel { Dock = DockStyle.Fill, BackColor = Color.White, Padding = new Padding(25) };
        root.Controls.Add(right, 1, 0);
        var qrLayout = new TableLayoutPanel { Dock = DockStyle.Fill, RowCount = 4 };
        qrLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 44));
        qrLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        qrLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 60));
        qrLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 44));
        right.Controls.Add(qrLayout);

        qrLayout.Controls.Add(new Label
        {
            Text = "휴대폰에서 QR 스캔",
            Dock = DockStyle.Fill,
            TextAlign = ContentAlignment.MiddleCenter,
            ForeColor = Color.FromArgb(20, 33, 61),
            Font = new Font("Segoe UI", 13F, FontStyle.Bold),
        });
        qrBox.Dock = DockStyle.Fill;
        qrBox.Margin = new Padding(18);
        qrLayout.Controls.Add(qrBox);
        emptyLabel.Text = "사용 가능한 유선/Wi-Fi 어댑터가 없습니다.\n네트워크 연결과 IP 설정을 확인해 주세요.";
        emptyLabel.TextAlign = ContentAlignment.MiddleCenter;
        emptyLabel.Dock = DockStyle.Fill;
        emptyLabel.ForeColor = Color.FromArgb(102, 112, 133);
        emptyLabel.Visible = false;
        qrLayout.Controls.Add(emptyLabel, 0, 1);

        qrLayout.Controls.Add(new Label
        {
            Text = "QR에는 PC 이름, MAC 주소, 브로드캐스트 주소와 포트만 들어갑니다.\n서버로 전송되는 정보는 없습니다.",
            Dock = DockStyle.Fill,
            TextAlign = ContentAlignment.MiddleCenter,
            ForeColor = Color.FromArgb(102, 112, 133),
            Font = new Font("Segoe UI", 8.5F),
        });
        linkLabel.Dock = DockStyle.Fill;
        linkLabel.AutoEllipsis = true;
        linkLabel.TextAlign = ContentAlignment.MiddleCenter;
        linkLabel.ForeColor = Color.FromArgb(152, 162, 179);
        linkLabel.Font = new Font("Consolas", 7.5F);
        qrLayout.Controls.Add(linkLabel);
    }

    private static Control FieldPanel(string label, Control input)
    {
        var panel = new TableLayoutPanel { Dock = DockStyle.Fill, RowCount = 2, Margin = new Padding(0, 5, 0, 5) };
        panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 23));
        panel.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        panel.Controls.Add(new Label { Text = label, Dock = DockStyle.Fill, ForeColor = Color.FromArgb(52, 64, 84), Font = new Font("Segoe UI", 9F, FontStyle.Bold) });
        input.Dock = DockStyle.Fill;
        input.Font = new Font("Segoe UI", 10F);
        panel.Controls.Add(input);
        return panel;
    }

    private void LoadAdapters()
    {
        var adapters = NetworkHelper.FindAdapters();
        adapterBox.Items.Clear();
        adapterBox.Items.AddRange(adapters.Cast<object>().ToArray());
        var preferred = adapters.FindIndex(adapter => adapter.Type == NetworkInterfaceType.Ethernet);
        if (adapters.Count > 0)
            adapterBox.SelectedIndex = preferred >= 0 ? preferred : 0;
        else
        {
            qrBox.Visible = false;
            emptyLabel.Visible = true;
            applyButton.Enabled = false;
        }
    }

    private void RefreshQr()
    {
        if (adapterBox.SelectedItem is not AdapterInfo adapter) return;
        warningLabel.Visible = adapter.IsWifi;
        warningLabel.Text = "Wi-Fi는 절전 상태의 WOL을 지원하지 않는 경우가 많습니다. 가능하면 유선 LAN을 사용하세요.";
        networkLabel.Text = $"IPv4  {adapter.Ip}     브로드캐스트  {adapter.Broadcast}";

        try
        {
            var uri = $"wakemypc://add?name={Uri.EscapeDataString(nameBox.Text.Trim())}&mac={Uri.EscapeDataString(adapter.Mac)}&bc={Uri.EscapeDataString(adapter.Broadcast)}&port={(int)portBox.Value}";
            using var generator = new QRCodeGenerator();
            using var data = generator.CreateQrCode(uri, QRCodeGenerator.ECCLevel.M);
            using var code = new QRCode(data);
            var old = qrBox.Image;
            qrBox.Image = code.GetGraphic(12, Color.FromArgb(20, 33, 61), Color.White, true);
            old?.Dispose();
            linkLabel.Text = uri;
        }
        catch (Exception ex)
        {
            CrashReporter.Write(ex);
            qrBox.Visible = false;
            emptyLabel.Text = $"QR 코드를 만들지 못했습니다.\n{ex.Message}\n\n%LocalAppData%\\WakeQR\\WakeQR.log를 확인해 주세요.";
            emptyLabel.Visible = true;
        }
    }

    private async Task ApplyWolSettingsAsync()
    {
        if (adapterBox.SelectedItem is not AdapterInfo adapter) return;
        var answer = MessageBox.Show(
            "선택한 어댑터의 매직 패킷 깨우기를 켜고, Windows 빠른 시작을 끕니다. 관리자 권한 요청이 표시됩니다.\n\nBIOS/UEFI의 Wake on LAN은 별도로 켜야 합니다.",
            "WOL 설정 적용",
            MessageBoxButtons.OKCancel,
            MessageBoxIcon.Information);
        if (answer != DialogResult.OK) return;

        applyButton.Enabled = false;
        applyButton.Text = "설정 적용 중…";
        try
        {
            var name = adapter.Name.Replace("'", "''");
            var description = adapter.Description.Replace("'", "''");
            var script = $@"
$ErrorActionPreference = 'Stop'
Set-NetAdapterPowerManagement -Name '{name}' -WakeOnMagicPacket Enabled -WakeOnPattern Disabled
powercfg.exe -deviceenablewake '{description}'
if ($LASTEXITCODE -ne 0) {{ throw 'powercfg 설정에 실패했습니다.' }}
Set-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Power' -Name HiberbootEnabled -Type DWord -Value 0
";
            var encoded = Convert.ToBase64String(Encoding.Unicode.GetBytes(script));
            var process = Process.Start(new ProcessStartInfo
            {
                FileName = "powershell.exe",
                Arguments = $"-NoProfile -ExecutionPolicy Bypass -EncodedCommand {encoded}",
                Verb = "runas",
                UseShellExecute = true,
                WindowStyle = ProcessWindowStyle.Hidden,
            });
            if (process is null) throw new InvalidOperationException("PowerShell을 시작하지 못했습니다.");
            await process.WaitForExitAsync();
            if (process.ExitCode != 0) throw new InvalidOperationException($"설정 명령이 종료 코드 {process.ExitCode}로 실패했습니다.");
            MessageBox.Show("WOL 설정을 적용했습니다. BIOS/UEFI에서도 Wake on LAN 또는 PCIe Wake가 켜져 있는지 확인하세요.", "완료", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        catch (System.ComponentModel.Win32Exception ex) when (ex.NativeErrorCode == 1223)
        {
            MessageBox.Show("관리자 권한 요청이 취소되어 설정을 변경하지 않았습니다.", "취소됨", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        catch (Exception ex)
        {
            MessageBox.Show($"WOL 설정을 모두 적용하지 못했습니다.\n\n{ex.Message}", "설정 실패", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        finally
        {
            applyButton.Enabled = true;
            applyButton.Text = "WOL 설정 자동 적용";
        }
    }
}

internal static class NetworkHelper
{
    private static readonly string[] Excluded =
    [
        "vmware", "virtualbox", "hyper-v", "vethernet", "tailscale", "vpn",
        "bluetooth", "loopback", "tunnel", "tap-windows", "wireguard"
    ];

    public static List<AdapterInfo> FindAdapters()
    {
        var result = new List<AdapterInfo>();
        NetworkInterface[] interfaces;
        try
        {
            interfaces = NetworkInterface.GetAllNetworkInterfaces();
        }
        catch (Exception ex)
        {
            CrashReporter.Write(ex);
            return result;
        }

        foreach (var nic in interfaces)
        {
            try
            {
                if (nic.OperationalStatus != OperationalStatus.Up ||
                    nic.NetworkInterfaceType is not (NetworkInterfaceType.Ethernet or NetworkInterfaceType.Wireless80211) ||
                    Excluded.Any(term => $"{nic.Name} {nic.Description}".Contains(term, StringComparison.OrdinalIgnoreCase)))
                    continue;

                var bytes = nic.GetPhysicalAddress().GetAddressBytes();
                if (bytes.Length != 6) continue;
                var properties = nic.GetIPProperties();
                if (!properties.GatewayAddresses.Any(gateway => gateway.Address.AddressFamily == AddressFamily.InterNetwork)) continue;
                var unicast = properties.UnicastAddresses.FirstOrDefault(address =>
                    address.Address.AddressFamily == AddressFamily.InterNetwork && address.IPv4Mask is not null);
                if (unicast?.IPv4Mask is null) continue;

                var mac = string.Join(":", bytes.Select(value => value.ToString("X2")));
                result.Add(new AdapterInfo(
                    nic.Name,
                    nic.Description,
                    mac,
                    unicast.Address.ToString(),
                    Broadcast(unicast.Address, unicast.IPv4Mask).ToString(),
                    nic.NetworkInterfaceType));
            }
            catch (Exception ex)
            {
                CrashReporter.Write(new InvalidOperationException($"네트워크 어댑터 '{nic.Name}' 정보를 읽지 못했습니다.", ex));
            }
        }
        return result.OrderBy(adapter => adapter.IsWifi).ThenBy(adapter => adapter.Name).ToList();
    }

    private static IPAddress Broadcast(IPAddress address, IPAddress mask)
    {
        var ip = address.GetAddressBytes();
        var subnet = mask.GetAddressBytes();
        return new IPAddress(ip.Select((value, index) => (byte)(value | ~subnet[index])).ToArray());
    }
}
