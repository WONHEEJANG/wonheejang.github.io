using System.Diagnostics;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Text;
using Open.Nat;
using QRCoder;

namespace WakeQR;

internal static class Program
{
    [STAThread]
    private static void Main()
    {
        Application.SetUnhandledExceptionMode(UnhandledExceptionMode.CatchException);
        Application.ThreadException += (_, args) => CrashReporter.Show(args.Exception);
        AppDomain.CurrentDomain.UnhandledException += (_, args) =>
            CrashReporter.Write(args.ExceptionObject as Exception ?? new Exception(args.ExceptionObject?.ToString()));

        try
        {
            ApplicationConfiguration.Initialize();
            Application.Run(new MainForm());
        }
        catch (Exception ex)
        {
            CrashReporter.Show(ex);
        }
    }
}

internal static class CrashReporter
{
    private static readonly string LogDirectory = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
        "WakeQR");

    public static void Write(Exception exception)
    {
        try
        {
            Directory.CreateDirectory(LogDirectory);
            File.AppendAllText(
                Path.Combine(LogDirectory, "WakeQR.log"),
                $"[{DateTimeOffset.Now:O}] WakeQR {Application.ProductVersion} | {Environment.OSVersion}\r\n{exception}\r\n\r\n");
        }
        catch
        {
            // Logging must never hide the original error.
        }
    }

    public static void Show(Exception exception)
    {
        Write(exception);
        MessageBox.Show(
            $"WakeQR를 실행하지 못했습니다.\n\n{exception.Message}\n\n오류 기록:\n{Path.Combine(LogDirectory, "WakeQR.log")}",
            "WakeQR 오류",
            MessageBoxButtons.OK,
            MessageBoxIcon.Error);
    }
}

internal sealed record AdapterInfo(
    string Name,
    string Description,
    string Mac,
    string Ip,
    string Broadcast,
    string Gateway,
    NetworkInterfaceType Type)
{
    public bool IsWifi => Type == NetworkInterfaceType.Wireless80211;
    public override string ToString() => $"{Name} ({Mac}){(IsWifi ? " · Wi-Fi" : string.Empty)}";
}

internal sealed class MainForm : Form
{
    private readonly ComboBox adapterBox = new() { DropDownStyle = ComboBoxStyle.DropDownList };
    private readonly TextBox nameBox = new();
    private readonly NumericUpDown portBox = new() { Minimum = 1, Maximum = 65535, Value = 9 };
    private readonly TextBox remoteHostBox = new() { PlaceholderText = "자동 설정 후 공인 IP가 표시됩니다" };
    private readonly NumericUpDown remotePortBox = new() { Minimum = 1, Maximum = 65535, Value = 40009 };
    private readonly CheckBox includeRemoteCheck = new() { Text = "외부 깨우기 정보를 QR에 포함", AutoSize = true };
    private readonly PictureBox qrBox = new() { SizeMode = PictureBoxSizeMode.Zoom };
    private readonly Label networkLabel = new();
    private readonly Label warningLabel = new();
    private readonly Label routerStatusLabel = new();
    private readonly Label emptyLabel = new();
    private readonly Button applyButton = new();
    private readonly Button routerButton = new();
    private readonly Button manualButton = new();
    private readonly Label linkLabel = new();

    public MainForm()
    {
        Text = "WakeQR";
        ClientSize = new Size(940, 720);
        MinimumSize = new Size(860, 680);
        StartPosition = FormStartPosition.CenterScreen;
        BackColor = Color.FromArgb(245, 247, 251);
        Font = new Font("Segoe UI", 10F);

        BuildLayout();
        nameBox.Text = Environment.MachineName;
        nameBox.TextChanged += (_, _) => RefreshQr();
        portBox.ValueChanged += (_, _) => RefreshQr();
        remoteHostBox.TextChanged += (_, _) => RefreshQr();
        remotePortBox.ValueChanged += (_, _) => RefreshQr();
        includeRemoteCheck.CheckedChanged += (_, _) => RefreshQr();
        adapterBox.SelectedIndexChanged += (_, _) => RefreshQr();
        LoadAdapters();
    }

    private void BuildLayout()
    {
        var root = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            Padding = new Padding(32),
            ColumnCount = 2,
            RowCount = 1,
            BackColor = BackColor,
        };
        root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 55));
        root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 45));
        Controls.Add(root);

        var left = new TableLayoutPanel { Dock = DockStyle.Fill, Padding = new Padding(0, 4, 26, 0), RowCount = 13 };
        left.RowStyles.Add(new RowStyle(SizeType.Absolute, 36));
        left.RowStyles.Add(new RowStyle(SizeType.Absolute, 48));
        left.RowStyles.Add(new RowStyle(SizeType.Absolute, 33));
        left.RowStyles.Add(new RowStyle(SizeType.Absolute, 70));
        left.RowStyles.Add(new RowStyle(SizeType.Absolute, 70));
        left.RowStyles.Add(new RowStyle(SizeType.Absolute, 70));
        left.RowStyles.Add(new RowStyle(SizeType.Absolute, 70));
        left.RowStyles.Add(new RowStyle(SizeType.Absolute, 70));
        left.RowStyles.Add(new RowStyle(SizeType.Absolute, 34));
        left.RowStyles.Add(new RowStyle(SizeType.Absolute, 42));
        left.RowStyles.Add(new RowStyle(SizeType.Absolute, 48));
        left.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        left.RowStyles.Add(new RowStyle(SizeType.Absolute, 56));
        root.Controls.Add(left, 0, 0);

        left.Controls.Add(new Label
        {
            Text = "WAKE ON LAN",
            ForeColor = Color.FromArgb(37, 99, 235),
            Font = new Font("Segoe UI", 9F, FontStyle.Bold),
            Dock = DockStyle.Fill,
            TextAlign = ContentAlignment.BottomLeft,
        });
        left.Controls.Add(new Label
        {
            Text = "WakeQR",
            ForeColor = Color.FromArgb(20, 33, 61),
            Font = new Font("Segoe UI", 24F, FontStyle.Bold),
            Dock = DockStyle.Fill,
        });
        left.Controls.Add(new Label
        {
            Text = "이 PC의 정보를 휴대폰으로 안전하게 옮깁니다.",
            ForeColor = Color.FromArgb(102, 112, 133),
            Dock = DockStyle.Fill,
        });

        left.Controls.Add(FieldPanel("네트워크 어댑터", adapterBox));
        left.Controls.Add(FieldPanel("PC 이름", nameBox));
        left.Controls.Add(FieldPanel("PC 내부 UDP 포트", portBox));
        left.Controls.Add(FieldPanel("외부 주소 (공인 IP 또는 DDNS)", remoteHostBox));
        left.Controls.Add(FieldPanel("공유기 외부 UDP 포트", remotePortBox));
        includeRemoteCheck.ForeColor = Color.FromArgb(52, 64, 84);
        includeRemoteCheck.Padding = new Padding(2, 2, 0, 0);
        left.Controls.Add(includeRemoteCheck);

        networkLabel.Dock = DockStyle.Fill;
        networkLabel.ForeColor = Color.FromArgb(71, 84, 103);
        networkLabel.Font = new Font("Segoe UI", 9F);
        networkLabel.Padding = new Padding(2, 8, 0, 0);
        left.Controls.Add(networkLabel);

        routerStatusLabel.Dock = DockStyle.Fill;
        routerStatusLabel.ForeColor = Color.FromArgb(71, 84, 103);
        routerStatusLabel.Padding = new Padding(10, 8, 10, 0);
        routerStatusLabel.BackColor = Color.FromArgb(239, 246, 255);
        routerStatusLabel.Text = "공유기 자동 설정을 실행하면 외부 깨우기까지 하나의 QR에 담깁니다.";
        left.Controls.Add(routerStatusLabel);

        warningLabel.Dock = DockStyle.Fill;
        warningLabel.ForeColor = Color.FromArgb(146, 64, 14);
        warningLabel.Padding = new Padding(10);
        warningLabel.BackColor = Color.FromArgb(255, 247, 237);
        warningLabel.Visible = false;
        left.Controls.Add(warningLabel);

        var actions = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 3, Padding = new Padding(0, 5, 0, 0) };
        actions.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 49));
        actions.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33));
        actions.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 18));
        StyleButton(routerButton, "공유기 자동 설정 + 통합 QR", Color.FromArgb(37, 99, 235), Color.White);
        routerButton.Click += async (_, _) => await ConfigureRouterAsync();
        actions.Controls.Add(routerButton);
        StyleButton(applyButton, "Windows WOL 설정", Color.FromArgb(20, 33, 61), Color.White);
        applyButton.Click += async (_, _) => await ApplyWolSettingsAsync();
        actions.Controls.Add(applyButton);
        StyleButton(manualButton, "수동 안내", Color.FromArgb(226, 232, 240), Color.FromArgb(30, 41, 59));
        manualButton.Click += (_, _) => ShowManualGuide();
        actions.Controls.Add(manualButton);
        left.Controls.Add(actions);

        var right = new Panel { Dock = DockStyle.Fill, BackColor = Color.White, Padding = new Padding(25) };
        root.Controls.Add(right, 1, 0);
        var qrLayout = new TableLayoutPanel { Dock = DockStyle.Fill, RowCount = 4 };
        qrLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 44));
        qrLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        qrLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 60));
        qrLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 44));
        right.Controls.Add(qrLayout);

        qrLayout.Controls.Add(new Label
        {
            Text = "휴대폰에서 QR 스캔",
            Dock = DockStyle.Fill,
            TextAlign = ContentAlignment.MiddleCenter,
            ForeColor = Color.FromArgb(20, 33, 61),
            Font = new Font("Segoe UI", 13F, FontStyle.Bold),
        });
        qrBox.Dock = DockStyle.Fill;
        qrBox.Margin = new Padding(18);
        qrLayout.Controls.Add(qrBox);
        emptyLabel.Text = "사용 가능한 유선/Wi-Fi 어댑터가 없습니다.\n네트워크 연결과 IP 설정을 확인해 주세요.";
        emptyLabel.TextAlign = ContentAlignment.MiddleCenter;
        emptyLabel.Dock = DockStyle.Fill;
        emptyLabel.ForeColor = Color.FromArgb(102, 112, 133);
        emptyLabel.Visible = false;
        qrLayout.Controls.Add(emptyLabel, 0, 1);

        qrLayout.Controls.Add(new Label
        {
            Text = "로컬 정보와 설정 완료된 외부 주소가 하나의 QR에 들어갑니다.\n공유기 비밀번호는 읽거나 QR에 저장하지 않습니다.",
            Dock = DockStyle.Fill,
            TextAlign = ContentAlignment.MiddleCenter,
            ForeColor = Color.FromArgb(102, 112, 133),
            Font = new Font("Segoe UI", 8.5F),
        });
        linkLabel.Dock = DockStyle.Fill;
        linkLabel.AutoEllipsis = true;
        linkLabel.TextAlign = ContentAlignment.MiddleCenter;
        linkLabel.ForeColor = Color.FromArgb(152, 162, 179);
        linkLabel.Font = new Font("Consolas", 7.5F);
        qrLayout.Controls.Add(linkLabel);
    }

    private static Control FieldPanel(string label, Control input)
    {
        var panel = new TableLayoutPanel { Dock = DockStyle.Fill, RowCount = 2, Margin = new Padding(0, 5, 0, 5) };
        panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 23));
        panel.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        panel.Controls.Add(new Label { Text = label, Dock = DockStyle.Fill, ForeColor = Color.FromArgb(52, 64, 84), Font = new Font("Segoe UI", 9F, FontStyle.Bold) });
        input.Dock = DockStyle.Fill;
        input.Font = new Font("Segoe UI", 10F);
        panel.Controls.Add(input);
        return panel;
    }

    private static void StyleButton(Button button, string text, Color backColor, Color foreColor)
    {
        button.Text = text;
        button.Dock = DockStyle.Fill;
        button.Margin = new Padding(0, 0, 6, 0);
        button.FlatStyle = FlatStyle.Flat;
        button.FlatAppearance.BorderSize = 0;
        button.BackColor = backColor;
        button.ForeColor = foreColor;
        button.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
        button.Cursor = Cursors.Hand;
    }

    private void LoadAdapters()
    {
        var adapters = NetworkHelper.FindAdapters();
        adapterBox.Items.Clear();
        adapterBox.Items.AddRange(adapters.Cast<object>().ToArray());
        var preferred = adapters.FindIndex(adapter => adapter.Type == NetworkInterfaceType.Ethernet);
        if (adapters.Count > 0)
            adapterBox.SelectedIndex = preferred >= 0 ? preferred : 0;
        else
        {
            qrBox.Visible = false;
            emptyLabel.Visible = true;
            applyButton.Enabled = false;
            routerButton.Enabled = false;
        }
    }

    private void RefreshQr()
    {
        if (adapterBox.SelectedItem is not AdapterInfo adapter) return;
        warningLabel.Visible = adapter.IsWifi;
        warningLabel.Text = "Wi-Fi는 절전 상태의 WOL을 지원하지 않는 경우가 많습니다. 가능하면 유선 LAN을 사용하세요.";
        networkLabel.Text = $"IPv4  {adapter.Ip}     브로드캐스트  {adapter.Broadcast}";

        try
        {
            var uri = $"wakemypc://add?name={Uri.EscapeDataString(nameBox.Text.Trim())}&mac={Uri.EscapeDataString(adapter.Mac)}&bc={Uri.EscapeDataString(adapter.Broadcast)}&port={(int)portBox.Value}&ip={Uri.EscapeDataString(adapter.Ip)}&gw={Uri.EscapeDataString(adapter.Gateway)}";
            if (includeRemoteCheck.Checked)
            {
                var host = remoteHostBox.Text.Trim();
                if (!NetworkHelper.IsValidRemoteHost(host))
                {
                    routerStatusLabel.Text = "외부 주소를 확인해 주세요. 공인 IPv4 또는 DDNS 도메인을 입력해야 합니다.";
                    routerStatusLabel.ForeColor = Color.FromArgb(185, 28, 28);
                    return;
                }
                uri += $"&wan={Uri.EscapeDataString(host)}&wanPort={(int)remotePortBox.Value}";
            }
            using var generator = new QRCodeGenerator();
            using var data = generator.CreateQrCode(uri, QRCodeGenerator.ECCLevel.M);
            using var code = new QRCode(data);
            var old = qrBox.Image;
            qrBox.Image = code.GetGraphic(12, Color.FromArgb(20, 33, 61), Color.White, true);
            old?.Dispose();
            linkLabel.Text = uri;
        }
        catch (Exception ex)
        {
            CrashReporter.Write(ex);
            qrBox.Visible = false;
            emptyLabel.Text = $"QR 코드를 만들지 못했습니다.\n{ex.Message}\n\n%LocalAppData%\\WakeQR\\WakeQR.log를 확인해 주세요.";
            emptyLabel.Visible = true;
        }
    }

    private async Task ConfigureRouterAsync()
    {
        if (adapterBox.SelectedItem is not AdapterInfo adapter) return;
        routerButton.Enabled = false;
        manualButton.Enabled = false;
        routerButton.Text = "공유기 찾는 중…";
        routerStatusLabel.Text = "UPnP를 지원하는 공유기를 찾고 있습니다. 최대 12초 정도 걸릴 수 있습니다.";
        routerStatusLabel.ForeColor = Color.FromArgb(30, 64, 175);

        try
        {
            var result = await RouterSetup.TryConfigureAsync((int)portBox.Value, (int)remotePortBox.Value);
            remoteHostBox.Text = result.ExternalIp;
            includeRemoteCheck.Checked = true;
            routerStatusLabel.Text = $"✓ 자동 설정 완료 · UDP {result.ExternalPort} → {adapter.Ip}:{result.InternalPort} · QR을 한 번 스캔하세요.";
            routerStatusLabel.ForeColor = Color.FromArgb(21, 128, 61);
            routerStatusLabel.BackColor = Color.FromArgb(240, 253, 244);
            RefreshQr();
            MessageBox.Show(
                "공유기 자동 설정과 통합 QR 생성이 끝났습니다.\n\n휴대폰에서 QR을 한 번 스캔하면 로컬·외부 깨우기 정보가 함께 등록됩니다. 공유기를 초기화하거나 교체한 경우에는 이 버튼을 다시 눌러 주세요.",
                "통합 QR 준비 완료",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
        }
        catch (Exception ex)
        {
            CrashReporter.Write(ex);
            includeRemoteCheck.Checked = false;
            routerStatusLabel.Text = "자동 설정을 지원하지 않는 공유기입니다. ‘수동 안내’에 표시된 값만 한 번 설정해 주세요.";
            routerStatusLabel.ForeColor = Color.FromArgb(180, 83, 9);
            routerStatusLabel.BackColor = Color.FromArgb(255, 247, 237);
            ShowManualGuide(ex.Message);
        }
        finally
        {
            routerButton.Enabled = true;
            manualButton.Enabled = true;
            routerButton.Text = "공유기 자동 설정 + 통합 QR";
        }
    }

    private void ShowManualGuide(string? reason = null)
    {
        if (adapterBox.SelectedItem is not AdapterInfo adapter) return;
        var message = new StringBuilder();
        if (!string.IsNullOrWhiteSpace(reason))
            message.AppendLine($"자동 설정 결과: {reason}\n");
        message.AppendLine("공유기 관리자 페이지에서 아래 값을 한 번만 설정하세요.\n");
        message.AppendLine($"관리자 주소: http://{adapter.Gateway}");
        message.AppendLine($"PC 고정 IP: {adapter.Ip}");
        message.AppendLine($"PC MAC: {adapter.Mac}");
        message.AppendLine($"포트포워딩: UDP {(int)remotePortBox.Value} → {adapter.Ip}:{(int)portBox.Value}");
        message.AppendLine("\n설정 후 공유기의 공인 IP 또는 DDNS 주소를 ‘외부 주소’에 입력하고, ‘외부 깨우기 정보를 QR에 포함’을 체크한 다음 QR을 스캔하세요.");
        MessageBox.Show(message.ToString(), "공유기 수동 설정 안내", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }

    private async Task ApplyWolSettingsAsync()
    {
        if (adapterBox.SelectedItem is not AdapterInfo adapter) return;
        var answer = MessageBox.Show(
            "선택한 어댑터의 매직 패킷 깨우기를 켜고, Windows 빠른 시작을 끕니다. 관리자 권한 요청이 표시됩니다.\n\nBIOS/UEFI의 Wake on LAN은 별도로 켜야 합니다.",
            "WOL 설정 적용",
            MessageBoxButtons.OKCancel,
            MessageBoxIcon.Information);
        if (answer != DialogResult.OK) return;

        applyButton.Enabled = false;
        applyButton.Text = "설정 적용 중…";
        try
        {
            var name = adapter.Name.Replace("'", "''");
            var description = adapter.Description.Replace("'", "''");
            var script = $@"
$ErrorActionPreference = 'Stop'
Set-NetAdapterPowerManagement -Name '{name}' -WakeOnMagicPacket Enabled -WakeOnPattern Disabled
powercfg.exe -deviceenablewake '{description}'
if ($LASTEXITCODE -ne 0) {{ throw 'powercfg 설정에 실패했습니다.' }}
Set-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Power' -Name HiberbootEnabled -Type DWord -Value 0
";
            var encoded = Convert.ToBase64String(Encoding.Unicode.GetBytes(script));
            var process = Process.Start(new ProcessStartInfo
            {
                FileName = "powershell.exe",
                Arguments = $"-NoProfile -ExecutionPolicy Bypass -EncodedCommand {encoded}",
                Verb = "runas",
                UseShellExecute = true,
                WindowStyle = ProcessWindowStyle.Hidden,
            });
            if (process is null) throw new InvalidOperationException("PowerShell을 시작하지 못했습니다.");
            await process.WaitForExitAsync();
            if (process.ExitCode != 0) throw new InvalidOperationException($"설정 명령이 종료 코드 {process.ExitCode}로 실패했습니다.");
            MessageBox.Show("WOL 설정을 적용했습니다. BIOS/UEFI에서도 Wake on LAN 또는 PCIe Wake가 켜져 있는지 확인하세요.", "완료", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        catch (System.ComponentModel.Win32Exception ex) when (ex.NativeErrorCode == 1223)
        {
            MessageBox.Show("관리자 권한 요청이 취소되어 설정을 변경하지 않았습니다.", "취소됨", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        catch (Exception ex)
        {
            MessageBox.Show($"WOL 설정을 모두 적용하지 못했습니다.\n\n{ex.Message}", "설정 실패", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        finally
        {
            applyButton.Enabled = true;
            applyButton.Text = "Windows WOL 설정";
        }
    }
}

internal sealed record RouterSetupResult(string ExternalIp, int InternalPort, int ExternalPort);

internal static class RouterSetup
{
    public static async Task<RouterSetupResult> TryConfigureAsync(int internalPort, int externalPort)
    {
        Exception? lastError = null;
        foreach (var mapper in new[] { PortMapper.Upnp, PortMapper.Pmp })
        {
            try
            {
                using var timeout = new CancellationTokenSource(TimeSpan.FromSeconds(6));
                var discoverer = new NatDiscoverer();
                var device = await discoverer.DiscoverDeviceAsync(mapper, timeout);
                var externalIp = await device.GetExternalIPAsync();
                if (!NetworkHelper.IsPublicIpv4(externalIp))
                    throw new InvalidOperationException($"공유기가 공인 IPv4 대신 {externalIp} 주소를 사용하고 있습니다. 통신사 이중 NAT 또는 CGNAT 환경에서는 일반 포트포워딩을 사용할 수 없습니다.");

                await device.CreatePortMapAsync(new Mapping(
                    Protocol.Udp,
                    internalPort,
                    externalPort,
                    "WakeMyPC remote wake"));

                return new RouterSetupResult(externalIp.ToString(), internalPort, externalPort);
            }
            catch (Exception ex)
            {
                lastError = ex;
            }
        }

        throw new InvalidOperationException(
            "UPnP/NAT-PMP 자동 포트 설정을 사용할 수 없습니다. 공유기에서 UPnP를 켜거나 수동 안내를 따라 주세요.",
            lastError);
    }
}

internal static class NetworkHelper
{
    private static readonly string[] Excluded =
    [
        "vmware", "virtualbox", "hyper-v", "vethernet", "tailscale", "vpn",
        "bluetooth", "loopback", "tunnel", "tap-windows", "wireguard"
    ];

    public static List<AdapterInfo> FindAdapters()
    {
        var result = new List<AdapterInfo>();
        NetworkInterface[] interfaces;
        try
        {
            interfaces = NetworkInterface.GetAllNetworkInterfaces();
        }
        catch (Exception ex)
        {
            CrashReporter.Write(ex);
            return result;
        }

        foreach (var nic in interfaces)
        {
            try
            {
                if (nic.OperationalStatus != OperationalStatus.Up ||
                    nic.NetworkInterfaceType is not (NetworkInterfaceType.Ethernet or NetworkInterfaceType.Wireless80211) ||
                    Excluded.Any(term => $"{nic.Name} {nic.Description}".Contains(term, StringComparison.OrdinalIgnoreCase)))
                    continue;

                var bytes = nic.GetPhysicalAddress().GetAddressBytes();
                if (bytes.Length != 6) continue;
                var properties = nic.GetIPProperties();
                var gateway = properties.GatewayAddresses.FirstOrDefault(item =>
                    item.Address.AddressFamily == AddressFamily.InterNetwork)?.Address;
                if (gateway is null) continue;
                var unicast = properties.UnicastAddresses.FirstOrDefault(address =>
                    address.Address.AddressFamily == AddressFamily.InterNetwork && address.IPv4Mask is not null);
                if (unicast?.IPv4Mask is null) continue;

                var mac = string.Join(":", bytes.Select(value => value.ToString("X2")));
                result.Add(new AdapterInfo(
                    nic.Name,
                    nic.Description,
                    mac,
                    unicast.Address.ToString(),
                    Broadcast(unicast.Address, unicast.IPv4Mask).ToString(),
                    gateway.ToString(),
                    nic.NetworkInterfaceType));
            }
            catch (Exception ex)
            {
                CrashReporter.Write(new InvalidOperationException($"네트워크 어댑터 '{nic.Name}' 정보를 읽지 못했습니다.", ex));
            }
        }
        return result.OrderBy(adapter => adapter.IsWifi).ThenBy(adapter => adapter.Name).ToList();
    }

    private static IPAddress Broadcast(IPAddress address, IPAddress mask)
    {
        var ip = address.GetAddressBytes();
        var subnet = mask.GetAddressBytes();
        return new IPAddress(ip.Select((value, index) => (byte)(value | ~subnet[index])).ToArray());
    }

    public static bool IsValidRemoteHost(string value)
    {
        var host = value.Trim();
        return IPAddress.TryParse(host, out var address)
            ? address.AddressFamily == AddressFamily.InterNetwork
            : Uri.CheckHostName(host) == UriHostNameType.Dns;
    }

    public static bool IsPublicIpv4(IPAddress address)
    {
        if (address.AddressFamily != AddressFamily.InterNetwork) return false;
        var bytes = address.GetAddressBytes();
        return bytes[0] != 0 &&
               bytes[0] != 10 &&
               bytes[0] != 127 &&
               !(bytes[0] == 169 && bytes[1] == 254) &&
               !(bytes[0] == 172 && bytes[1] is >= 16 and <= 31) &&
               !(bytes[0] == 192 && bytes[1] == 168) &&
               !(bytes[0] == 100 && bytes[1] is >= 64 and <= 127) &&
               bytes[0] < 224;
    }
}
